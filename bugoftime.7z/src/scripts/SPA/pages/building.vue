<template>
  <div class="main">
    <h2 class="content-title">样例</h2>
    <div class="content-field"></div>
  </div>
</template>
<script>
import loading from 'commonScripts/zWaiting.ts';
export default {
  data() {
    return {}
  },
  components: {},
  methods: {},
  created() {
    loading.show();
  }
}
</script>
//环境变量
// window.APISERVER = 'http://192.168.1.6:885/';
window.APISERVER = 'http://192.168.1.250:885/';//内部测试
// window.APISERVER = 'http://tstapi.jdhui.com.cn/'; //线上测试

// window.UPLOADSERVER = 'http://192.168.1.6:910/api/UploadFile/UploadFiles'; //文件资源站本地
window.UPLOADSERVER = 'http://tstpic.jdhui.com.cn/api/UploadFile/UploadFiles'; //文件资源站

window._WEBCONFIG = {
  Version: '1PC-1.0.0', //软件版本
  // Version: 'iOS100', //软件版本
};